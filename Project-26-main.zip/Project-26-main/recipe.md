Step-by-Step Recipe:

1. Take Gram flour.

2. In a bowl add batter, 1/2 tsp salt, 1/2 tsp green chilli Paste, 1/2 tsp grated ginger, 1/4th tsp salt, Add 1/8th tsp turmeric and mix well.

3. Grease the plate with oil.

4. Place the batter plate in steamer.

For Tempering:

1. Add 1 tsp oil, 1/4th tsp Mustard seeds, some Curry leaves, 1 tsp chopped green chillies, 1/8th tsp Asafoetida(Hing) and (5.0ml)water.

2. Add tempering to dhokla.


Your Tasty & Spongy {Khaman-Dhokla} is ready.
