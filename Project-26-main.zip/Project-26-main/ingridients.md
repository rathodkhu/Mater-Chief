Ingredients:

(For Batter)
1. 3 Tbsp Gram flour
2. 1/2 Tbsp Green chilli paste
3. 1/2 Tbsp Ginger grated
4. 1/8 Tbsp Turmeric
5. 1/2 Tbsp Salt
6. Water(as required)For Batter

(For Tempering)
1. 1 Tbsp Green chilli chopped
2. some Curry leaves
3. 1/4 Tbsp Mustard seeds
4. 1/8 Tbsp Asafoetida(Hing)
5. 1 Tbsp lemon juice
6. 1 Tbsp oil
7. Water (as required)for Tempering
